import subprocess
import sys


def assurer(module, paquet):
    try:
        __import__(module)
    except ImportError:
        print(f"Installation de {paquet} ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", paquet])


assurer("numpy", "numpy")
assurer("cv2", "opencv-python<5")
assurer("pynput", "pynput")
assurer("PIL", "pillow")

import ctypes
import json
import threading
import time
import traceback
from pathlib import Path

import cv2
import numpy as np
from pynput import keyboard, mouse

# ---------------- Réglages ----------------
PAS = 2.0             # pas de la souris sur les contours (px)
PAS_LIGNE = 3.0       # pas de la souris sur les hachures (px)
DELAI = 0.0015        # pause entre points (plus grand = plus lent, plus propre)
TRAIT_COUT = 0.045    # temps perdu à chaque trait (poser/lever le crayon)
ESPACEMENT_MIN = 1.8  # écart minimal entre deux hachures (px)
VK_NUMPAD0 = 96
PEN_COUT = 0.8        # temps pour changer de stylo (clic dans le ruban)

# Couleurs de stylos proposées (nom, RGB)
PALETTE = [("noir", (0, 0, 0)), ("rouge", (220, 30, 30)), ("bleu", (30, 60, 220)),
           ("vert", (30, 150, 50)), ("jaune", (255, 215, 0)), ("orange", (255, 140, 0)),
           ("violet", (130, 50, 170)), ("marron", (120, 70, 30)),
           ("rose", (255, 130, 180)), ("gris", (130, 130, 130))]

# Couches d'ombres : (angle en degrés, seuil de noirceur 0-255)
COUCHES_RAPIDE = [(45, 60), (135, 130)]
COUCHES_ULTRA = [(45, 30), (135, 60), (0, 90), (90, 120),
                 (22, 150), (112, 180), (67, 210)]
# ------------------------------------------

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
    ctypes.windll.winmm.timeBeginPeriod(1)
except Exception:
    pass

souris = mouse.Controller()
clavier = keyboard.Controller()
stop = threading.Event()
etat = {"en_cours": False}


# ---------- Utilitaires ----------
def demander(texte, defaut, valides=None):
    while True:
        r = input(f"{texte} [{defaut}] : ").strip()
        if r == "":
            return defaut
        if r.isdigit() and (valides is None or int(r) in valides):
            return int(r)


def choisir_image() -> Path:
    dossier = Path(__file__).resolve().parent
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
    images = sorted(p for p in dossier.iterdir()
                    if p.suffix.lower() in exts and not p.name.startswith("apercu"))
    if not images:
        raise RuntimeError("Aucune image (png/jpg/bmp/webp) dans le dossier du programme.")
    if len(images) == 1:
        return images[0]
    print("Images trouvées :")
    for i, p in enumerate(images, 1):
        print(f"  {i}. {p.name}")
    n = demander("Numéro de l'image", 1, range(1, len(images) + 1))
    return images[n - 1]


def charger(chemin: Path, taille: int, couleur=False):
    data = np.fromfile(str(chemin), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise RuntimeError("Impossible de lire l'image.")
    if img.ndim == 3 and img.shape[2] == 4:            # transparence -> fond blanc
        a = img[:, :, 3:4].astype(np.float32) / 255
        rgb = img[:, :, :3].astype(np.float32)
        img = (rgb * a + 255 * (1 - a)).astype(np.uint8)
    if img.ndim == 2 and couleur:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif img.ndim == 3 and not couleur:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = img.shape[:2]
    e = taille / max(h, w)
    interp = cv2.INTER_AREA if e < 1 else cv2.INTER_CUBIC
    return cv2.resize(img, (max(1, int(w * e)), max(1, int(h * e))), interpolation=interp)


def calibrer():
    """Mesure le temps réel par point de souris."""
    x0, y0 = souris.position
    n = 200
    t0 = time.perf_counter()
    for i in range(n):
        souris.position = (x0 + (i % 2), y0)
        time.sleep(DELAI)
    dt = (time.perf_counter() - t0) / n
    souris.position = (x0, y0)
    return dt


def estimer(chemins, dt_pt):
    t = 0.0
    for pts, pas in chemins:
        if pts is None:
            if pas.get("editeur"):                    # ouvrir la fenêtre, saisir, OK
                ed = pas["editeur"]
                t += 1.6 + 0.8 * len(ed["pre"]) + 0.7 * len(ed["champs"])
            else:
                t += PEN_COUT + 0.8 * (len(pas.get("etapes", [])) + len(pas.get("apres", [])))
            continue
        if len(pts) < 2:
            continue
        longueur = float(np.linalg.norm(np.diff(np.asarray(pts, np.float32), axis=0), axis=1).sum())
        t += max(1.0, longueur / pas) * dt_pt + TRAIT_COUT
    return t * 1.15


def format_duree(s):
    s = int(s)
    return f"{s // 60} min {s % 60:02d} s"


# ---------- Modes 1 et 2 : contours / traits noirs ----------
def amincir(binaire):
    """Squelettisation de Zhang-Suen (traits d'un pixel d'épaisseur)."""
    img = (binaire > 0).astype(np.uint8)
    change = True
    while change:
        change = False
        for etape in (0, 1):
            P = np.pad(img, 1)
            p2, p3, p4 = P[:-2, 1:-1], P[:-2, 2:], P[1:-1, 2:]
            p5, p6, p7 = P[2:, 2:], P[2:, 1:-1], P[2:, :-2]
            p8, p9 = P[1:-1, :-2], P[:-2, :-2]
            seq = [p2, p3, p4, p5, p6, p7, p8, p9, p2]
            nb = sum(s.astype(np.int16) for s in seq[:8])
            trans = sum(((seq[i] == 0) & (seq[i + 1] == 1)).astype(np.int16)
                        for i in range(8))
            if etape == 0:
                c = ((p2 * p4 * p6) == 0) & ((p4 * p6 * p8) == 0)
            else:
                c = ((p2 * p4 * p8) == 0) & ((p2 * p6 * p8) == 0)
            m = (img == 1) & (nb >= 2) & (nb <= 6) & (trans == 1) & c
            if m.any():
                img[m] = 0
                change = True
    return img


D8 = [(-1, 0), (0, 1), (1, 0), (0, -1), (-1, -1), (-1, 1), (1, 1), (1, -1)]


def tracer_squelette(sq):
    pts = set(zip(*np.nonzero(sq)))

    def voisins(p):
        y, x = p
        return [(y + dy, x + dx) for dy, dx in D8 if (y + dy, x + dx) in pts]

    deg = {p: len(voisins(p)) for p in pts}
    ordre = [p for p in sorted(pts) if deg[p] == 1] + \
            [p for p in sorted(pts) if deg[p] != 1]
    vus, chemins = set(), []
    for s in ordre:
        if s in vus:
            continue
        chemin = [s]
        vus.add(s)
        cur, prev = s, None
        while True:
            cand = [n for n in voisins(cur) if n not in vus]
            if not cand:
                break
            if prev is None:
                nxt = cand[0]
            else:
                d0 = (cur[0] - prev[0], cur[1] - prev[1])
                nxt = max(cand, key=lambda n: d0[0] * (n[0] - cur[0]) + d0[1] * (n[1] - cur[1]))
            vus.add(nxt)
            chemin.append(nxt)
            prev, cur = cur, nxt
        if len(chemin) > 3 and s in voisins(cur):
            chemin.append(s)
        chemins.append(np.array([(x, y) for y, x in chemin], dtype=np.int32))
    return chemins


def ordonner(chemins):
    if not chemins:
        return chemins
    restants = list(range(len(chemins)))
    debuts = np.array([c[0] for c in chemins], dtype=np.float32)
    fins = np.array([c[-1] for c in chemins], dtype=np.float32)
    cur = np.array([0.0, 0.0], dtype=np.float32)
    resultat = []
    while restants:
        idx = np.array(restants)
        dd = np.linalg.norm(debuts[idx] - cur, axis=1)
        df = np.linalg.norm(fins[idx] - cur, axis=1)
        i, j = int(dd.argmin()), int(df.argmin())
        if dd[i] <= df[j]:
            k = restants.pop(i)
            c = chemins[k]
        else:
            k = restants.pop(j)
            c = chemins[k][::-1]
        resultat.append(c)
        cur = c[-1].astype(np.float32)
    return resultat


def traits_contours(gris, detail, mode, mini=None):
    if mode == 1:
        g = cv2.bilateralFilter(gris, 5, 40, 40)
        med = float(np.median(g))
        f = {1: 1.7, 2: 1.3, 3: 1.0, 4: 0.75, 5: 0.5}[detail]
        bas = int(max(10, 0.66 * med * f))
        haut = int(max(bas + 20, 1.33 * med * f))
        bords = cv2.Canny(g, bas, haut)
        bords = cv2.dilate(bords, np.ones((3, 3), np.uint8))
    else:
        g = cv2.GaussianBlur(gris, (3, 3), 0)
        _, bw = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        if bw.mean() > 127:
            bw = 255 - bw
        bords = bw

    sq = amincir(bords)
    if mini is None:
        mini = {1: 25, 2: 16, 3: 10, 4: 7, 5: 5}[detail]
    finaux = []
    for c in tracer_squelette(sq):
        if len(c) < mini:
            continue
        s = cv2.approxPolyDP(c.reshape(-1, 1, 2), 0.7, False).reshape(-1, 2)
        if len(s) >= 2:
            finaux.append(s)
    return [(c, PAS) for c in ordonner(finaux)]


# ---------- Modes 3 et 4 : hachures ----------
def preparer_ton(gris):
    lo, hi = np.percentile(gris, (1, 99))
    if hi - lo < 10:
        hi = lo + 10
    g = np.clip((gris.astype(np.float32) - lo) * 255 / (hi - lo), 0, 255).astype(np.uint8)
    g = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8)).apply(g)
    return cv2.GaussianBlur(g, (3, 3), 0)


def matrice(w, h, angle):
    diag = int(np.ceil(np.hypot(w, h))) + 2
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    M[0, 2] += diag / 2 - w / 2
    M[1, 2] += diag / 2 - h / 2
    return M, diag


def preparer_masques(ton, niveaux):
    h, w = ton.shape
    sombre = 255 - ton
    res = []
    for angle, seuil in niveaux:
        masque = ((sombre > seuil) * 255).astype(np.uint8)
        masque = cv2.medianBlur(masque, 5)
        M, diag = matrice(w, h, angle)
        rot = cv2.warpAffine(masque, M, (diag, diag), flags=cv2.INTER_NEAREST)
        Mi = cv2.invertAffineTransform(M)
        res.append((rot > 0, Mi))
    return res


def lignes(rot, Mi, esp):
    """Hachures parallèles d'une couche : segments (2 points) en zigzag."""
    diag = rot.shape[0]
    debuts, fins, ys = [], [], []
    for n, y in enumerate(np.arange(esp / 2, diag, esp)):
        yi = int(y)
        if yi >= diag:
            break
        r = rot[yi].astype(np.int8)
        if not r.any():
            continue
        d = np.diff(np.concatenate(([0], r, [0])))
        s = np.nonzero(d == 1)[0]
        e = np.nonzero(d == -1)[0] - 1
        if len(s) > 1:                         # fusionne les petits trous
            garde = (s[1:] - e[:-1]) > 4
            s = np.concatenate(([s[0]], s[1:][garde]))
            e = np.concatenate((e[:-1][garde], [e[-1]]))
        ok = (e - s) >= 3
        s, e = s[ok], e[ok]
        if len(s) == 0:
            continue
        if n % 2 == 1:                          # zigzag : sens inverse
            s, e = e[::-1], s[::-1]
        debuts.extend(s.tolist())
        fins.extend(e.tolist())
        ys.extend([yi] * len(s))
    if not ys:
        return []
    A = np.stack([debuts, ys], axis=1).astype(np.float32)
    B = np.stack([fins, ys], axis=1).astype(np.float32)
    A = A @ Mi[:, :2].T.astype(np.float32) + Mi[:, 2].astype(np.float32)
    B = B @ Mi[:, :2].T.astype(np.float32) + Mi[:, 2].astype(np.float32)
    return [(np.stack([a, b]), PAS_LIGNE) for a, b in zip(A, B)]


def generer(masques, esp):
    out = []
    for rot, Mi in masques:
        out.extend(lignes(rot, Mi, esp))
    return out


def generer_groupes(groupes, esp):
    """groupes = [(stylo ou None, masques)] ; insère un changement de stylo avant chaque groupe."""
    out = []
    for stylo, masques in groupes:
        seg = generer(masques, esp)
        if not seg:
            continue
        if stylo is not None:
            out.append((None, stylo))
        out.extend(seg)
    return out


def hachures_budget(groupes, budget, dt, fixe):
    """Cherche l'espacement le plus fin qui tient dans la durée demandée."""
    lo, hi = ESPACEMENT_MIN, 40.0
    ch = generer_groupes(groupes, lo)
    if estimer(ch, dt) + fixe <= budget:
        return ch, lo
    best = None
    for _ in range(9):
        mid = (lo + hi) / 2
        ch = generer_groupes(groupes, mid)
        if estimer(ch, dt) + fixe <= budget:
            best = (ch, mid)
            hi = mid
        else:
            lo = mid
    if best is None:
        best = (generer_groupes(groupes, hi), hi)
    return best


# ---------- Préparation générale ----------
def preparer(chemin, taille, detail, mode, minutes, dt, stylos=None):
    gris = charger(chemin, taille)
    if mode in (1, 2):
        traits = traits_contours(gris, detail, mode)
        info = ""
    elif mode in (3, 4):
        ton = preparer_ton(gris)
        contours = []
        if mode == 4:
            contours = traits_contours(gris, 2, 1, mini=30)
        fixe = estimer(contours, dt) if contours else 0.0
        niveaux = COUCHES_RAPIDE if mode == 3 else COUCHES_ULTRA
        groupes = [(None, preparer_masques(ton, niveaux))]
        hach, esp = hachures_budget(groupes, minutes * 60, dt, fixe)
        traits = hach + contours
        info = f" (espacement des hachures : {esp:.1f} px)"
    else:  # mode 5 : couleur
        img = charger(chemin, taille, couleur=True)
        gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        encre = 255 - img.min(axis=2)                     # quantité d'encre voulue
        ton = preparer_ton(255 - encre)
        lab = cv2.cvtColor(img.astype(np.float32) / 255, cv2.COLOR_BGR2Lab)
        pal = np.array([[s["bgr"] for s in stylos]], dtype=np.float32) / 255
        pal_lab = cv2.cvtColor(pal, cv2.COLOR_BGR2Lab)[0]
        dist = ((lab[:, :, None, :] - pal_lab[None, None, :, :]) ** 2).sum(-1)
        attribue = dist.argmin(axis=2)
        niveaux = COUCHES_ULTRA if minutes >= 10 else COUCHES_RAPIDE
        groupes = []
        for k in np.argsort(-pal_lab[:, 0]):              # du plus clair au plus sombre
            ton_k = np.where(attribue == k, ton, 255).astype(np.uint8)
            groupes.append((stylos[k], preparer_masques(ton_k, niveaux)))
        noir = next((s for s in stylos if s["nom"] == "noir"), None)
        contours = traits_contours(gris, 2, 1, mini=30) if noir else []
        fixe = estimer(contours, dt) + PEN_COUT if contours else 0.0
        hach, esp = hachures_budget(groupes, minutes * 60, dt, fixe)
        dernier = next((t[1] for t in reversed(hach) if t[0] is None), None)
        fin = []
        if contours:
            if dernier is None or dernier["nom"] != "noir":
                fin.append((None, noir))
            fin.extend(contours)
        traits = hach + fin
        info = f" (espacement des hachures : {esp:.1f} px)"
    if not any(t[0] is not None for t in traits):
        raise RuntimeError("Aucun trait détecté. Augmente le détail ou change de mode.")

    apercu = np.full((*gris.shape[:2], 3), 255, np.uint8)
    col = (0, 0, 0)
    for pts, pas in traits:
        if pts is None:
            col = pas["bgr"]
            continue
        p = np.round(np.asarray(pts, np.float32)).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(apercu, [p], False, col, 1, cv2.LINE_AA)
    ok, buf = cv2.imencode(".png", apercu)
    if ok:
        buf.tofile(str(Path(__file__).resolve().parent / "apercu.png"))
    return traits, info


def configurer_stylos():
    print()
    print("Mode couleur : chaque couleur utilise un stylo différent du ruban Word.")
    print("Dans Word (onglet Dessin), donne d'abord une couleur à chaque stylo :")
    print("clique 2 fois sur le stylo -> choisis la couleur (et une épaisseur fine).")
    n = demander("Nombre de stylos à utiliser", 3, range(2, 7))
    stylos = []
    pris = set()
    for i in range(1, n + 1):
        print(f"\nStylo {i}/{n} - couleurs possibles :")
        for k, (nom, _) in enumerate(PALETTE, 1):
            print(f"  {k}. {nom}")
        while True:
            c = demander("Couleur de ce stylo", 1, range(1, len(PALETTE) + 1))
            if PALETTE[c - 1][0] in pris:
                print("Cette couleur est déjà prise, choisis-en une autre.")
                continue
            break
        nom, rgb = PALETTE[c - 1]
        pris.add(nom)
        print(f"Dans Word, le stylo {nom} doit avoir cette couleur, et être un stylo DIFFERENT des autres.")
        input("Appuie sur Entrée ici, puis tu as 6 s pour poser la souris sur ce stylo dans Word (sans cliquer)...")
        for sec in range(6, 0, -1):
            print(f"  {sec}...", end="\r")
            time.sleep(1)
        pos = tuple(souris.position)
        print(f"  Position enregistrée : {pos}   ")
        stylos.append({"nom": nom, "bgr": (rgb[2], rgb[1], rgb[0]), "pos": pos})
    return stylos


# ---------- Modes 6 et 7 : couleur dans Paint 3D ----------
FICHIER_PALETTE = Path(__file__).resolve().parent / "palette.json"
FICHIER_ZONE = Path(__file__).resolve().parent / "zone.png"


def lire_pixel(x, y):
    """Couleur [B, G, R] affichée à l'écran au point (x, y)."""
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
    user32.GetDC.restype = ctypes.c_void_p
    user32.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    gdi32.GetPixel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    gdi32.GetPixel.restype = ctypes.c_uint32
    hdc = user32.GetDC(None)
    vals = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            c = gdi32.GetPixel(hdc, int(x) + dx, int(y) + dy)
            if c != 0xFFFFFFFF:
                vals.append((c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF))  # R, G, B
    user32.ReleaseDC(None, hdc)
    if not vals:
        raise RuntimeError("Impossible de lire la couleur à l'écran.")
    r, g, b = np.mean(vals, axis=0)
    return [int(b), int(g), int(r)]


def capturer_zone(rect):
    """Capture d'écran (BGR) du rectangle [x0, y0, x1, y1]."""
    from PIL import ImageGrab
    x0, y0, x1, y1 = rect
    im = ImageGrab.grab(bbox=(x0, y0, x1 + 1, y1 + 1), all_screens=True)
    return np.array(im.convert("RGB"))[:, :, ::-1].copy()


def calibrer_palette():
    print()
    print("=== Apprentissage de la palette Paint 3D ===")
    print("Dans Paint 3D : Pinceaux > choisis ton pinceau, la palette doit être visible.")
    print()
    print("A) ZONE (conseillé : le robot trouve tout seul les couleurs dont il a besoin)")
    print("   1. Si la palette n'est visible qu'après un ou plusieurs clics, place la souris")
    print("      sur chaque bouton et appuie sur - (le programme enregistre ET clique pour toi).")
    print("   2. Place la souris sur un bord/coin de la palette, appuie sur / du pavé numérique.")
    print("      Fais-le pour les 4 coins (ordre libre) : le robot photographie la zone.")
    print("   3. Optionnel : place la souris sur un bouton à cliquer APRÈS le choix de la couleur")
    print("      (OK, Terminé...) et appuie sur + (point de validation, enregistré sans cliquer)")
    print("      ou sur - (enregistré ET cliqué).")
    print()
    print("B) MANUEL (pastille par pastille)")
    print("   Survole une pastille, appuie sur +. Répète. Un - avant le + ajoute une étape")
    print("   à cliquer avant cette pastille (ex. 'toutes les couleurs').")
    print()
    print()
    print("C) ÉDITEUR DE COULEUR (n'importe quelle couleur, saisie automatique)")
    print("   1. Place la souris sur le bouton qui ouvre la fenêtre 'Modifier la couleur'")
    print("      (la grande pastille sous 'Personnalisé') et appuie sur - : il clique et la fenêtre s'ouvre.")
    print("   2. Place la souris sur chaque champ et appuie sur 1 du pavé numérique, dans cet ordre :")
    print("      ROUGE, VERT, BLEU, HEXADÉCIMAL (4 points).")
    print("      Pour n'utiliser que l'hexadécimal : ne pose qu'UN point, sur HEXADÉCIMAL.")
    print("   3. Place la souris sur le bouton OK et appuie sur + : l'apprentissage est terminé.")
    print("      (ferme ensuite la fenêtre toi-même avec Annuler)")
    print()
    print("Dans tous les cas : . (point) annule la dernière action, * termine.")

    palette, etapes, coins, post, histo = [], [], [], [], []
    champs, ed = [], {"ok": None}
    zone = {"rect": None, "img": None, "pre": []}
    fini = threading.Event()

    def avec_zone():
        return zone["rect"] is not None

    def ajouter():                                   # touche +
        try:
            x, y = souris.position
            if champs:                                   # + sur le bouton OK de l'éditeur
                if len(champs) not in (1, 3, 4):
                    print(f"  {len(champs)} champ(s) posé(s) : il en faut 1 (hexadécimal), 3 (R, V, B) ou 4.")
                    return
                ed["ok"] = [int(x), int(y)]
                print(f"  Bouton OK enregistré en ({x}, {y}). Apprentissage terminé.")
                fini.set()
                return
            if avec_zone():
                post.append([int(x), int(y)])
                histo.append("post")
                print(f"  Point de validation {len(post)} enregistré en ({x}, {y}).")
                return
            bgr = lire_pixel(x, y)
            palette.append({"nom": f"couleur {len(palette) + 1}", "pos": [int(x), int(y)],
                            "bgr": bgr, "etapes": [list(e) for e in etapes]})
            histo.append("couleur")
            print(f"  Couleur {len(palette)} : RVB {bgr[::-1]} en ({x}, {y})"
                  f"  [{len(etapes)} étape(s) avant]")
            etapes.clear()
        except Exception as e:
            print("  Erreur :", e)

    def etape():                                     # touche -
        x, y = souris.position
        if avec_zone():
            post.append([int(x), int(y)])
            histo.append("post")
            print(f"  Étape après sélection {len(post)} enregistrée en ({x}, {y}) : clic automatique...")
        else:
            etapes.append([int(x), int(y)])
            histo.append("etape")
            print(f"  Étape {len(etapes)} enregistrée en ({x}, {y}) : clic automatique...")

        def cliquer():
            time.sleep(0.3)
            souris.position = (x, y)
            souris.click(mouse.Button.left)
            time.sleep(0.6)
            print("  Continue : / pour un coin de palette, + pour une pastille, ou * pour finir.")
        threading.Thread(target=cliquer, daemon=True).start()

    def champ():                                     # touche 1 (pavé numérique)
        if avec_zone() or palette or coins:
            print("  Touche 1 réservée à la méthode C (éditeur de couleur) : annule d'abord avec .")
            return
        if len(champs) >= 4:
            print("  4 champs déjà posés : place la souris sur OK et appuie sur +.")
            return
        x, y = souris.position
        champs.append([int(x), int(y)])
        histo.append("champ")
        n = len(champs)
        print(f"  Point {n} enregistré en ({x}, {y}).")
        if n == 1:
            print("  Si c'est le champ HEXADÉCIMAL et que tu n'utilises que lui : + sur OK maintenant.")
            print("  Sinon c'était ROUGE : continue avec VERT, BLEU (puis HEXADÉCIMAL si tu veux).")
        elif n == 3:
            print("  Tu peux ajouter HEXADÉCIMAL (1) ou finir avec + sur OK.")
        elif n == 4:
            print("  Place la souris sur OK et appuie sur +.")

    def coin():                                      # touche / (diviser)
        if avec_zone():
            print("  La zone est déjà définie. Appuie sur . pour annuler un coin.")
            return
        x, y = souris.position
        coins.append([int(x), int(y)])
        histo.append("coin")
        print(f"  Coin {len(coins)}/4 enregistré en ({x}, {y})")
        if len(coins) < 4:
            return
        xs, ys = [c[0] for c in coins], [c[1] for c in coins]
        rect = [min(xs), min(ys), max(xs), max(ys)]
        if rect[2] - rect[0] < 10 or rect[3] - rect[1] < 10:
            print("  Zone trop petite : écarte les coins. Coins effacés.")
            coins.clear()
            histo[:] = [h for h in histo if h != "coin"]
            return
        zone["rect"] = rect
        zone["pre"] = [list(e) for e in etapes]
        etapes.clear()

        def prendre():
            try:
                zone["img"] = capturer_zone(rect)
                h, w = zone["img"].shape[:2]
                print(f"  Zone enregistrée : {w} x {h} px, {len(zone['pre'])} étape(s) avant.")
                print("  Tu peux ajouter un point de validation avec + (optionnel), puis * pour finir.")
            except Exception as e:
                print("  Erreur de capture :", e)
                zone["rect"] = None
        threading.Thread(target=prendre, daemon=True).start()

    def annuler():                                   # touche . (point)
        while histo:
            a = histo.pop()
            if a == "etape" and etapes:
                etapes.pop()
                print("  Dernière étape annulée.")
                return
            if a == "post" and post:
                post.pop()
                print("  Dernier point après sélection annulé.")
                return
            if a == "champ" and champs:
                champs.pop()
                print(f"  Dernier champ annulé ({len(champs)} restants).")
                return
            if a == "coin" and coins:
                coins.pop()
                if zone["rect"] is not None:
                    etapes[:] = zone["pre"]
                    zone.update(rect=None, img=None, pre=[])
                print(f"  Dernier coin annulé ({len(coins)}/4).")
                return
            if a == "couleur" and palette:
                palette.pop()
                print(f"  Dernière couleur supprimée ({len(palette)} restantes).")
                return
        print("  Rien à annuler.")

    def filtre(msg, data):
        if data.vkCode in (97, 106, 107, 109, 110, 111):    # 1  *  +  -  .  /
            if msg in (0x100, 0x104) and not bool(data.flags & 0x10):
                if data.vkCode == 107:
                    ajouter()
                elif data.vkCode == 109:
                    etape()
                elif data.vkCode == 110:
                    annuler()
                elif data.vkCode == 111:
                    coin()
                elif data.vkCode == 97:
                    champ()
                else:
                    fini.set()
            cal.suppress_event()
        return True

    cal = keyboard.Listener(win32_event_filter=filtre)
    cal.start()
    try:
        while True:
            if fini.is_set():
                if ed["ok"] is not None:
                    break
                elif champs:
                    print("  Il manque le + sur le bouton OK.")
                    fini.clear()
                elif avec_zone():
                    if zone["img"] is not None:
                        break                        # sinon : capture en cours, on attend
                elif not coins and len(palette) >= 2:
                    break
                else:
                    print("  Il faut 4 coins (/) ou au moins 2 pastilles (+).")
                    fini.clear()
            time.sleep(0.1)
    finally:
        cal.stop()

    if ed["ok"] is not None:
        noms = {1: ["hex"], 3: ["rouge", "vert", "bleu"], 4: ["rouge", "vert", "bleu", "hex"]}[len(champs)]
        cfg = {"type": "editeur", "pre": [list(e) for e in etapes],
               "champs": dict(zip(noms, champs)), "ok": ed["ok"]}
        FICHIER_PALETTE.write_text(json.dumps(cfg), encoding="utf-8")
        print(f"Éditeur de couleur enregistré ({len(etapes)} étape(s) avant, champs : {', '.join(noms)}).")
    elif avec_zone():
        ok, buf = cv2.imencode(".png", zone["img"])
        if ok:
            buf.tofile(str(FICHIER_ZONE))
        cfg = {"type": "zone", "rect": zone["rect"], "pre": zone["pre"], "post": post}
        FICHIER_PALETTE.write_text(json.dumps(cfg), encoding="utf-8")
        cfg["zone_img"] = zone["img"]
        print("Zone enregistrée (palette.json + zone.png).")
    else:
        cfg = {"type": "manuel", "couleurs": palette}
        FICHIER_PALETTE.write_text(json.dumps(cfg), encoding="utf-8")
        print(f"Palette enregistrée ({len(palette)} couleurs) dans palette.json")
    return cfg


def charger_palette():
    if not FICHIER_PALETTE.exists():
        return None
    try:
        data = json.loads(FICHIER_PALETTE.read_text(encoding="utf-8"))
        if isinstance(data, list):                    # ancien format
            data = {"type": "manuel", "couleurs": data}
        if data["type"] == "editeur":
            return data if data.get("champs") and data.get("ok") else None
        if data["type"] == "zone":
            img = cv2.imdecode(np.fromfile(str(FICHIER_ZONE), dtype=np.uint8), cv2.IMREAD_COLOR)
            if img is None:
                return None
            data["zone_img"] = img
            return data
        return data if len(data["couleurs"]) >= 2 else None
    except Exception:
        return None


def palette_depuis_zone(cfg, bgr, nb):
    """Choisit nb couleurs dominantes de l'image et trouve où cliquer dans la zone."""
    zone = cfg["zone_img"]
    x0, y0 = cfg["rect"][0], cfg["rect"][1]
    lisse = cv2.bilateralFilter(bgr, 7, 60, 60)
    pix = cv2.cvtColor(lisse, cv2.COLOR_BGR2LAB).reshape(-1, 3)
    non_blanc = lisse.reshape(-1, 3).min(axis=1) <= 235
    if non_blanc.sum() >= nb * 20:
        pix = pix[non_blanc]
    if len(pix) > 20000:
        pix = pix[np.random.default_rng(0).choice(len(pix), 20000, replace=False)]
    pix = pix.astype(np.float32)
    k = max(2, min(nb, len(pix)))
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.5)
    _, _, centres = cv2.kmeans(pix, k, None, crit, 3, cv2.KMEANS_PP_CENTERS)

    zl = cv2.cvtColor(zone, cv2.COLOR_BGR2LAB).astype(np.float32)
    m1 = cv2.blur(zl, (5, 5))
    var = (cv2.blur(zl * zl, (5, 5)) - m1 * m1).sum(axis=2)
    valide = var < 12.0                                # évite les bords des pastilles
    if valide.sum() < 30:
        valide = np.ones(valide.shape, bool)

    palette = []
    for t in centres:
        d = ((zl - t) ** 2).sum(axis=2)
        d[~valide] = np.inf
        idx = int(np.argmin(d))
        cand = (d <= d.flat[idx] + 6.0).astype(np.uint8)
        _, lbl = cv2.connectedComponents(cand, connectivity=8)
        comp = (lbl == lbl.flat[idx]).astype(np.uint8)
        dtm = cv2.distanceTransform(comp, cv2.DIST_L2, 3)
        cy, cx = np.unravel_index(int(np.argmax(dtm)), dtm.shape)
        if any(abs(q["pos"][0] - (x0 + cx)) < 6 and abs(q["pos"][1] - (y0 + cy)) < 6
               for q in palette):
            continue
        patch = zone[max(0, cy - 1):cy + 2, max(0, cx - 1):cx + 2].reshape(-1, 3).mean(axis=0)
        palette.append({"nom": f"zone {len(palette) + 1}", "pos": [int(x0 + cx), int(y0 + cy)],
                        "bgr": [int(v) for v in patch],
                        "etapes": [list(e) for e in cfg["pre"]],
                        "apres": [list(e) for e in cfg["post"]]})
    if len(palette) < 2:
        raise RuntimeError("La zone contient trop peu de couleurs différentes. Vérifie les 4 coins.")
    print(f"{len(palette)} couleurs trouvées dans la zone de la palette.")
    return palette


def couleurs_image(bgr, nb):
    """nb couleurs dominantes de l'image (liste de [b, g, r])."""
    lisse = cv2.bilateralFilter(bgr, 7, 60, 60)
    lab = cv2.cvtColor(lisse, cv2.COLOR_BGR2LAB).reshape(-1, 3)
    non_blanc = lisse.reshape(-1, 3).min(axis=1) <= 235
    pix = lab[non_blanc] if non_blanc.sum() >= nb * 20 else lab
    if len(pix) > 20000:
        pix = pix[np.random.default_rng(0).choice(len(pix), 20000, replace=False)]
    pix = pix.astype(np.float32)
    k = max(2, min(nb, len(pix)))
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.5)
    _, _, centres = cv2.kmeans(pix, k, None, crit, 3, cv2.KMEANS_PP_CENTERS)
    centres = np.clip(centres, 0, 255).astype(np.uint8).reshape(-1, 1, 3)
    bgrs = cv2.cvtColor(centres, cv2.COLOR_LAB2BGR).reshape(-1, 3)
    uniques = []
    for c in bgrs:
        c = [int(v) for v in c]
        if c not in uniques:
            uniques.append(c)
    return uniques


def palette_editeur(cfg, bgr, nb, saisie):
    ch = cfg["champs"]
    if "hex" in ch and (saisie == 1 or "rouge" not in ch):
        ordre = [("hex", ch["hex"])]
    else:
        ordre = [(n, ch[n]) for n in ("rouge", "vert", "bleu")]
    ed = {"pre": cfg["pre"], "champs": ordre, "ok": cfg["ok"]}
    pal = [{"nom": f"couleur {i + 1}", "bgr": c, "editeur": ed}
           for i, c in enumerate(couleurs_image(bgr, nb))]
    if len(pal) < 2:
        raise RuntimeError("L'image n'a pas assez de couleurs différentes.")
    print(f"{len(pal)} couleurs choisies dans l'image (saisie : "
          f"{'hexadécimal' if len(ordre) == 1 else 'rouge/vert/bleu'}).")
    return pal


def parametres_paint3d(ultra=False):
    cfg = charger_palette()
    if cfg:
        if cfg["type"] == "zone":
            print("Zone de palette enregistrée trouvée.")
        elif cfg["type"] == "editeur":
            print("Éditeur de couleur enregistré trouvé (couleurs libres).")
        else:
            print(f"Palette manuelle enregistrée trouvée ({len(cfg['couleurs'])} couleurs).")
        print("  1 = l'utiliser   2 = la refaire (si Paint 3D a bougé)")
        if demander("Choix", 1, (1, 2)) == 2:
            cfg = None
    if not cfg:
        cfg = calibrer_palette()
    prm = {"cfg": cfg, "ignorer": True, "contours": True, "epaisseur": 3, "nb": 10}
    if cfg["type"] == "editeur" and len(cfg["champs"]) == 4:
        prm["saisie"] = demander("Saisie : 1 = hexadécimal seul (rapide), 2 = Rouge/Vert/Bleu", 1, (1, 2))
    if cfg["type"] in ("zone", "editeur"):
        prm["nb"] = demander("Nombre de couleurs à utiliser (max, la zone sert de nuancier)",
                             12 if ultra else 10, range(2, 31))
    if not ultra:
        prm["epaisseur"] = demander("Épaisseur du pinceau en pixels écran (essaie 6)", 6, range(1, 60))
        prm["ignorer"] = demander("Ne pas dessiner le fond blanc ? 1 = oui, 2 = non", 1, (1, 2)) == 1
        prm["contours"] = demander("Ajouter des contours dans la couleur la plus sombre ? "
                                   "1 = oui, 2 = non", 1, (1, 2)) == 1
    return prm


def palette_pour_image(prm, image, taille):
    cfg = prm["cfg"]
    if cfg["type"] == "manuel":
        return cfg["couleurs"]
    bgr = charger(image, taille, couleur=True)
    if cfg["type"] == "editeur":
        return palette_editeur(cfg, bgr, prm["nb"], prm.get("saisie", 1))
    return palette_depuis_zone(cfg, bgr, prm["nb"])


def stylos_ultra(palette):
    """Copie de la palette ; la couleur la plus sombre devient 'noir' (pour les contours)."""
    st = [dict(q) for q in palette]
    if not any(q["nom"] == "noir" for q in st):
        lab = cv2.cvtColor(np.array([q["bgr"] for q in st], np.uint8).reshape(-1, 1, 3),
                           cv2.COLOR_BGR2LAB).reshape(-1, 3)
        st[int(np.argmin(lab[:, 0]))]["nom"] = "noir"
    return st


def ecrire_apercu(forme, traits, epaisseur=1):
    apercu = np.full((forme[0], forme[1], 3), 255, np.uint8)
    col = (0, 0, 0)
    for pts, pas in traits:
        if pts is None:
            col = tuple(int(v) for v in pas["bgr"])
            continue
        p = np.round(np.asarray(pts, np.float32)).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(apercu, [p], False, col, epaisseur, cv2.LINE_AA)
    ok, buf = cv2.imencode(".png", apercu)
    if ok:
        buf.tofile(str(Path(__file__).resolve().parent / "apercu.png"))


def preparer_paint3d(chemin, taille, prm):
    palette, epaisseur = prm["palette"], prm["epaisseur"]
    bgr = charger(chemin, taille, couleur=True)
    lisse = cv2.bilateralFilter(bgr, 7, 60, 60)
    lab = cv2.cvtColor(lisse, cv2.COLOR_BGR2LAB).astype(np.float32)
    pal_bgr = np.array([q["bgr"] for q in palette], np.uint8).reshape(-1, 1, 3)
    pal_lab = cv2.cvtColor(pal_bgr, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)

    h, w = lab.shape[:2]
    meilleur = np.full((h, w), np.inf, np.float32)
    etiq = np.zeros((h, w), np.int32)
    for k in range(len(palette)):
        dk = ((lab - pal_lab[k]) ** 2).sum(axis=2)
        m = dk < meilleur
        etiq[m] = k
        meilleur[m] = dk[m]

    blanc = (lisse.min(axis=2) > 235) if prm["ignorer"] else np.zeros((h, w), bool)
    identite = np.array([[1, 0, 0], [0, 1, 0]], np.float64)
    traits = []
    for k in np.argsort(-pal_lab[:, 0]):             # du plus clair au plus sombre
        masque = ((etiq == k) & ~blanc).astype(np.uint8) * 255
        masque = cv2.medianBlur(masque, 5)
        if (masque > 0).sum() < epaisseur * epaisseur:
            continue
        segs = lignes(masque > 0, identite, float(epaisseur))
        if segs:
            traits.append((None, palette[int(k)]))
            traits.extend(segs)

    if prm["contours"]:
        gris = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        cont = traits_contours(gris, 3, 1, mini=20)
        if cont:
            traits.append((None, palette[int(np.argmin(pal_lab[:, 0]))]))
            traits.extend(cont)

    if not any(t[0] is not None for t in traits):
        raise RuntimeError("Rien à dessiner. Mets 'ne pas dessiner le fond blanc' sur 2.")
    ecrire_apercu((h, w), traits, max(1, int(round(epaisseur))))
    return traits, ""


# ---------- Dessin ----------
def bouger(x, y):
    souris.position = (int(round(x)), int(round(y)))


def cliquer_en(x, y, attente=0.3):
    souris.position = (int(x), int(y))
    time.sleep(0.2)
    souris.click(mouse.Button.left)
    time.sleep(attente)


def saisir_texte(texte):
    with clavier.pressed(keyboard.Key.ctrl):
        clavier.press("a")
        clavier.release("a")
    time.sleep(0.1)
    for ch in texte:
        clavier.press(ch)
        clavier.release(ch)
        time.sleep(0.03)
    time.sleep(0.1)
    clavier.press(keyboard.Key.tab)                  # valide la saisie
    clavier.release(keyboard.Key.tab)
    time.sleep(0.2)


def choisir_couleur_editeur(ed, bgr):
    """Ouvre la fenêtre 'Modifier la couleur', tape la couleur, clique OK."""
    b, g, r = [int(v) for v in bgr]
    for ex, ey in ed["pre"]:
        cliquer_en(ex, ey, 0.6)
    time.sleep(0.4)
    for nom, (fx, fy) in ed["champs"]:
        if stop.is_set():
            return
        valeur = f"{r:02x}{g:02x}{b:02x}" if nom == "hex" else str({"rouge": r, "vert": g, "bleu": b}[nom])
        cliquer_en(fx, fy, 0.15)
        saisir_texte(valeur)
    cliquer_en(ed["ok"][0], ed["ok"][1], 0.6)


def dessiner(traits):
    try:
        ox, oy = souris.position
        print("Dessin en cours... (0 pour annuler)")
        debut = time.time()
        for pts, pas in traits:
            if stop.is_set():
                break
            if pts is None:                      # changement de stylo / couleur
                if pas.get("editeur"):
                    choisir_couleur_editeur(pas["editeur"], pas["bgr"])
                    continue
                suite = ([(e, 0.6) for e in pas.get("etapes", [])] + [(pas["pos"], 0.5)]
                         + [(e, 0.5) for e in pas.get("apres", [])])
                for (ex, ey), attente in suite:
                    if stop.is_set():
                        break
                    souris.position = (int(ex), int(ey))
                    time.sleep(0.2)
                    souris.click(mouse.Button.left)
                    time.sleep(attente)
                continue
            pts = np.asarray(pts, np.float32)
            bouger(ox + pts[0][0], oy + pts[0][1])
            time.sleep(0.008)
            souris.press(mouse.Button.left)
            time.sleep(0.008)
            for a, b in zip(pts[:-1], pts[1:]):
                if stop.is_set():
                    break
                n = max(1, int(np.hypot(*(b - a)) / pas))
                for t in range(1, n + 1):
                    bouger(ox + a[0] + (b[0] - a[0]) * t / n,
                           oy + a[1] + (b[1] - a[1]) * t / n)
                    time.sleep(DELAI)
            souris.release(mouse.Button.left)
            time.sleep(0.004)
        if stop.is_set():
            print("Annulé.")
        else:
            print(f"Terminé en {format_duree(time.time() - debut)}.")
    except Exception:
        traceback.print_exc()
    finally:
        try:
            souris.release(mouse.Button.left)
        except Exception:
            pass
        etat["en_cours"] = False


def main():
    print("Python utilisé :", sys.executable)
    image = choisir_image()
    print()
    print("Modes :")
    print("  1 = Contours        (logos, formes simples)")
    print("  2 = Traits noirs    (dessins, texte)")
    print("  3 = Hachures        (photos, rendu crayon rapide)")
    print("  4 = Ultra réaliste  (photos, 7 couches d'ombres + contours)")
    print("  5 = Couleur Word    (photos, plusieurs stylos de couleur dans Word)")
    print("  6 = Couleur Paint 3D (change de couleur tout seul, remplissage)")
    print("  7 = Couleur Paint 3D ULTRA réaliste (palette + étapes + hachures croisées)")
    mode = demander("Mode", 1, (1, 2, 3, 4, 5, 6, 7))
    taille = demander("Taille du dessin en pixels", 800 if mode in (4, 5, 7) else 600)
    detail, minutes, dt, stylos, p3d = 3, 0, 0.0, None, None
    if mode in (6, 7):
        p3d = parametres_paint3d(ultra=(mode == 7))
        p3d["palette"] = palette_pour_image(p3d, image, taille)
        if mode == 7:
            stylos = stylos_ultra(p3d["palette"])
            minutes = demander("Durée maximale en minutes", 20, range(1, 61))
        print("Mesure de la vitesse de la souris...")
        dt = calibrer()
    elif mode in (1, 2):
        detail = demander("Détail (1 à 5)", 3, range(1, 6))
    else:
        if mode == 5:
            stylos = configurer_stylos()
        minutes = demander("Durée maximale en minutes",
                           20 if mode >= 4 else 5, range(1, 61))
        print("Mesure de la vitesse de la souris...")
        dt = calibrer()

    print("Analyse de l'image (peut prendre quelques secondes)...")
    if mode == 6:
        traits, info = preparer_paint3d(image, taille, p3d)
    else:
        traits, info = preparer(image, taille, detail, 5 if mode == 7 else mode,
                                minutes, dt, stylos)
    if mode in (3, 4, 5, 6, 7):
        estim = estimer(traits, dt)
        print(f"Durée estimée : {format_duree(estim)}{info}")
    print(f"{len(traits)} traits. Aperçu enregistré : apercu.png (ouvre-le pour vérifier)")
    print()
    if mode == 7:
        print("Mode ultra : prends un pinceau FIN (crayon), sinon les hachures se fondent en aplat.")
    if mode in (6, 7):
        print("Dans Paint 3D : Pinceaux > MÊME pinceau et MÊME épaisseur que pendant l'apprentissage,")
        print("palette visible, fenêtre à la même place. Ne la déplace pas.")
        print("Le programme clique tout seul sur chaque couleur. Ne touche plus à la souris.")
    elif mode == 5:
        print("Dans Word : onglet Dessin > sélectionne l'outil FLECHE (pas un stylo !).")
        print("Le programme clique tout seul sur chaque stylo. Ne touche plus à la souris.")
    else:
        print("Dans Word : onglet Dessin > Crayon FIN (clique 2 fois pour régler l'épaisseur).")
    print("Place le curseur au coin haut-gauche voulu, puis appuie sur 0 du pavé numérique.")
    print("Rappuie sur 0 pour annuler. Ctrl+C ici pour quitter.")

    def filtre(msg, data):
        if data.vkCode == VK_NUMPAD0:
            injecte = bool(data.flags & 0x10)
            if msg in (0x100, 0x104) and not injecte:
                if etat["en_cours"]:
                    stop.set()
                else:
                    stop.clear()
                    etat["en_cours"] = True
                    threading.Thread(target=dessiner, args=(traits,), daemon=True).start()
            listener.suppress_event()
        return True

    listener = keyboard.Listener(win32_event_filter=filtre)
    listener.start()
    try:
        listener.join()
    except KeyboardInterrupt:
        stop.set()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
    input("\nAppuie sur Entrée pour fermer...")
