import subprocess
import sys


def assurer(module, paquet):
    try:
        __import__(module)
    except ImportError:
        print(f"Installation de {paquet} ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", paquet])


assurer("numpy", "numpy")
assurer("cv2", "opencv-python<5")
assurer("pynput", "pynput")

import ctypes
import json
import threading
import time
import traceback
from pathlib import Path

import cv2
import numpy as np
from pynput import keyboard, mouse

# ---------------- Réglages ----------------
PAS = 2.0             # pas de la souris sur les contours (px)
PAS_LIGNE = 3.0       # pas de la souris sur les hachures (px)
DELAI = 0.0015        # pause entre points (plus grand = plus lent, plus propre)
TRAIT_COUT = 0.045    # temps perdu à chaque trait (poser/lever le crayon)
ESPACEMENT_MIN = 1.8  # écart minimal entre deux hachures (px)
VK_NUMPAD0 = 96
PEN_COUT = 0.8        # temps pour changer de stylo (clic dans le ruban)

# Couleurs de stylos proposées (nom, RGB)
PALETTE = [("noir", (0, 0, 0)), ("rouge", (220, 30, 30)), ("bleu", (30, 60, 220)),
           ("vert", (30, 150, 50)), ("jaune", (255, 215, 0)), ("orange", (255, 140, 0)),
           ("violet", (130, 50, 170)), ("marron", (120, 70, 30)),
           ("rose", (255, 130, 180)), ("gris", (130, 130, 130))]

# Couches d'ombres : (angle en degrés, seuil de noirceur 0-255)
COUCHES_RAPIDE = [(45, 60), (135, 130)]
COUCHES_ULTRA = [(45, 30), (135, 60), (0, 90), (90, 120),
                 (22, 150), (112, 180), (67, 210)]
# ------------------------------------------

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
    ctypes.windll.winmm.timeBeginPeriod(1)
except Exception:
    pass

souris = mouse.Controller()
stop = threading.Event()
etat = {"en_cours": False}


# ---------- Utilitaires ----------
def demander(texte, defaut, valides=None):
    while True:
        r = input(f"{texte} [{defaut}] : ").strip()
        if r == "":
            return defaut
        if r.isdigit() and (valides is None or int(r) in valides):
            return int(r)


def choisir_image() -> Path:
    dossier = Path(__file__).resolve().parent
    exts = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}
    images = sorted(p for p in dossier.iterdir()
                    if p.suffix.lower() in exts and not p.name.startswith("apercu"))
    if not images:
        raise RuntimeError("Aucune image (png/jpg/bmp/webp) dans le dossier du programme.")
    if len(images) == 1:
        return images[0]
    print("Images trouvées :")
    for i, p in enumerate(images, 1):
        print(f"  {i}. {p.name}")
    n = demander("Numéro de l'image", 1, range(1, len(images) + 1))
    return images[n - 1]


def charger(chemin: Path, taille: int, couleur=False):
    data = np.fromfile(str(chemin), dtype=np.uint8)
    img = cv2.imdecode(data, cv2.IMREAD_UNCHANGED)
    if img is None:
        raise RuntimeError("Impossible de lire l'image.")
    if img.ndim == 3 and img.shape[2] == 4:            # transparence -> fond blanc
        a = img[:, :, 3:4].astype(np.float32) / 255
        rgb = img[:, :, :3].astype(np.float32)
        img = (rgb * a + 255 * (1 - a)).astype(np.uint8)
    if img.ndim == 2 and couleur:
        img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    elif img.ndim == 3 and not couleur:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = img.shape[:2]
    e = taille / max(h, w)
    interp = cv2.INTER_AREA if e < 1 else cv2.INTER_CUBIC
    return cv2.resize(img, (max(1, int(w * e)), max(1, int(h * e))), interpolation=interp)


def calibrer():
    """Mesure le temps réel par point de souris."""
    x0, y0 = souris.position
    n = 200
    t0 = time.perf_counter()
    for i in range(n):
        souris.position = (x0 + (i % 2), y0)
        time.sleep(DELAI)
    dt = (time.perf_counter() - t0) / n
    souris.position = (x0, y0)
    return dt


def estimer(chemins, dt_pt):
    t = 0.0
    for pts, pas in chemins:
        if pts is None:
            t += PEN_COUT
            continue
        if len(pts) < 2:
            continue
        longueur = float(np.linalg.norm(np.diff(np.asarray(pts, np.float32), axis=0), axis=1).sum())
        t += max(1.0, longueur / pas) * dt_pt + TRAIT_COUT
    return t * 1.15


def format_duree(s):
    s = int(s)
    return f"{s // 60} min {s % 60:02d} s"


# ---------- Modes 1 et 2 : contours / traits noirs ----------
def amincir(binaire):
    """Squelettisation de Zhang-Suen (traits d'un pixel d'épaisseur)."""
    img = (binaire > 0).astype(np.uint8)
    change = True
    while change:
        change = False
        for etape in (0, 1):
            P = np.pad(img, 1)
            p2, p3, p4 = P[:-2, 1:-1], P[:-2, 2:], P[1:-1, 2:]
            p5, p6, p7 = P[2:, 2:], P[2:, 1:-1], P[2:, :-2]
            p8, p9 = P[1:-1, :-2], P[:-2, :-2]
            seq = [p2, p3, p4, p5, p6, p7, p8, p9, p2]
            nb = sum(s.astype(np.int16) for s in seq[:8])
            trans = sum(((seq[i] == 0) & (seq[i + 1] == 1)).astype(np.int16)
                        for i in range(8))
            if etape == 0:
                c = ((p2 * p4 * p6) == 0) & ((p4 * p6 * p8) == 0)
            else:
                c = ((p2 * p4 * p8) == 0) & ((p2 * p6 * p8) == 0)
            m = (img == 1) & (nb >= 2) & (nb <= 6) & (trans == 1) & c
            if m.any():
                img[m] = 0
                change = True
    return img


D8 = [(-1, 0), (0, 1), (1, 0), (0, -1), (-1, -1), (-1, 1), (1, 1), (1, -1)]


def tracer_squelette(sq):
    pts = set(zip(*np.nonzero(sq)))

    def voisins(p):
        y, x = p
        return [(y + dy, x + dx) for dy, dx in D8 if (y + dy, x + dx) in pts]

    deg = {p: len(voisins(p)) for p in pts}
    ordre = [p for p in sorted(pts) if deg[p] == 1] + \
            [p for p in sorted(pts) if deg[p] != 1]
    vus, chemins = set(), []
    for s in ordre:
        if s in vus:
            continue
        chemin = [s]
        vus.add(s)
        cur, prev = s, None
        while True:
            cand = [n for n in voisins(cur) if n not in vus]
            if not cand:
                break
            if prev is None:
                nxt = cand[0]
            else:
                d0 = (cur[0] - prev[0], cur[1] - prev[1])
                nxt = max(cand, key=lambda n: d0[0] * (n[0] - cur[0]) + d0[1] * (n[1] - cur[1]))
            vus.add(nxt)
            chemin.append(nxt)
            prev, cur = cur, nxt
        if len(chemin) > 3 and s in voisins(cur):
            chemin.append(s)
        chemins.append(np.array([(x, y) for y, x in chemin], dtype=np.int32))
    return chemins


def ordonner(chemins):
    if not chemins:
        return chemins
    restants = list(range(len(chemins)))
    debuts = np.array([c[0] for c in chemins], dtype=np.float32)
    fins = np.array([c[-1] for c in chemins], dtype=np.float32)
    cur = np.array([0.0, 0.0], dtype=np.float32)
    resultat = []
    while restants:
        idx = np.array(restants)
        dd = np.linalg.norm(debuts[idx] - cur, axis=1)
        df = np.linalg.norm(fins[idx] - cur, axis=1)
        i, j = int(dd.argmin()), int(df.argmin())
        if dd[i] <= df[j]:
            k = restants.pop(i)
            c = chemins[k]
        else:
            k = restants.pop(j)
            c = chemins[k][::-1]
        resultat.append(c)
        cur = c[-1].astype(np.float32)
    return resultat


def traits_contours(gris, detail, mode, mini=None):
    if mode == 1:
        g = cv2.bilateralFilter(gris, 5, 40, 40)
        med = float(np.median(g))
        f = {1: 1.7, 2: 1.3, 3: 1.0, 4: 0.75, 5: 0.5}[detail]
        bas = int(max(10, 0.66 * med * f))
        haut = int(max(bas + 20, 1.33 * med * f))
        bords = cv2.Canny(g, bas, haut)
        bords = cv2.dilate(bords, np.ones((3, 3), np.uint8))
    else:
        g = cv2.GaussianBlur(gris, (3, 3), 0)
        _, bw = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        if bw.mean() > 127:
            bw = 255 - bw
        bords = bw

    sq = amincir(bords)
    if mini is None:
        mini = {1: 25, 2: 16, 3: 10, 4: 7, 5: 5}[detail]
    finaux = []
    for c in tracer_squelette(sq):
        if len(c) < mini:
            continue
        s = cv2.approxPolyDP(c.reshape(-1, 1, 2), 0.7, False).reshape(-1, 2)
        if len(s) >= 2:
            finaux.append(s)
    return [(c, PAS) for c in ordonner(finaux)]


# ---------- Modes 3 et 4 : hachures ----------
def preparer_ton(gris):
    lo, hi = np.percentile(gris, (1, 99))
    if hi - lo < 10:
        hi = lo + 10
    g = np.clip((gris.astype(np.float32) - lo) * 255 / (hi - lo), 0, 255).astype(np.uint8)
    g = cv2.createCLAHE(clipLimit=1.5, tileGridSize=(8, 8)).apply(g)
    return cv2.GaussianBlur(g, (3, 3), 0)


def matrice(w, h, angle):
    diag = int(np.ceil(np.hypot(w, h))) + 2
    M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    M[0, 2] += diag / 2 - w / 2
    M[1, 2] += diag / 2 - h / 2
    return M, diag


def preparer_masques(ton, niveaux):
    h, w = ton.shape
    sombre = 255 - ton
    res = []
    for angle, seuil in niveaux:
        masque = ((sombre > seuil) * 255).astype(np.uint8)
        masque = cv2.medianBlur(masque, 5)
        M, diag = matrice(w, h, angle)
        rot = cv2.warpAffine(masque, M, (diag, diag), flags=cv2.INTER_NEAREST)
        Mi = cv2.invertAffineTransform(M)
        res.append((rot > 0, Mi))
    return res


def lignes(rot, Mi, esp):
    """Hachures parallèles d'une couche : segments (2 points) en zigzag."""
    diag = rot.shape[0]
    debuts, fins, ys = [], [], []
    for n, y in enumerate(np.arange(esp / 2, diag, esp)):
        yi = int(y)
        if yi >= diag:
            break
        r = rot[yi].astype(np.int8)
        if not r.any():
            continue
        d = np.diff(np.concatenate(([0], r, [0])))
        s = np.nonzero(d == 1)[0]
        e = np.nonzero(d == -1)[0] - 1
        if len(s) > 1:                         # fusionne les petits trous
            garde = (s[1:] - e[:-1]) > 4
            s = np.concatenate(([s[0]], s[1:][garde]))
            e = np.concatenate((e[:-1][garde], [e[-1]]))
        ok = (e - s) >= 3
        s, e = s[ok], e[ok]
        if len(s) == 0:
            continue
        if n % 2 == 1:                          # zigzag : sens inverse
            s, e = e[::-1], s[::-1]
        debuts.extend(s.tolist())
        fins.extend(e.tolist())
        ys.extend([yi] * len(s))
    if not ys:
        return []
    A = np.stack([debuts, ys], axis=1).astype(np.float32)
    B = np.stack([fins, ys], axis=1).astype(np.float32)
    A = A @ Mi[:, :2].T.astype(np.float32) + Mi[:, 2].astype(np.float32)
    B = B @ Mi[:, :2].T.astype(np.float32) + Mi[:, 2].astype(np.float32)
    return [(np.stack([a, b]), PAS_LIGNE) for a, b in zip(A, B)]


def generer(masques, esp):
    out = []
    for rot, Mi in masques:
        out.extend(lignes(rot, Mi, esp))
    return out


def generer_groupes(groupes, esp):
    """groupes = [(stylo ou None, masques)] ; insère un changement de stylo avant chaque groupe."""
    out = []
    for stylo, masques in groupes:
        seg = generer(masques, esp)
        if not seg:
            continue
        if stylo is not None:
            out.append((None, stylo))
        out.extend(seg)
    return out


def hachures_budget(groupes, budget, dt, fixe):
    """Cherche l'espacement le plus fin qui tient dans la durée demandée."""
    lo, hi = ESPACEMENT_MIN, 40.0
    ch = generer_groupes(groupes, lo)
    if estimer(ch, dt) + fixe <= budget:
        return ch, lo
    best = None
    for _ in range(9):
        mid = (lo + hi) / 2
        ch = generer_groupes(groupes, mid)
        if estimer(ch, dt) + fixe <= budget:
            best = (ch, mid)
            hi = mid
        else:
            lo = mid
    if best is None:
        best = (generer_groupes(groupes, hi), hi)
    return best


# ---------- Préparation générale ----------
def preparer(chemin, taille, detail, mode, minutes, dt, stylos=None):
    gris = charger(chemin, taille)
    if mode in (1, 2):
        traits = traits_contours(gris, detail, mode)
        info = ""
    elif mode in (3, 4):
        ton = preparer_ton(gris)
        contours = []
        if mode == 4:
            contours = traits_contours(gris, 2, 1, mini=30)
        fixe = estimer(contours, dt) if contours else 0.0
        niveaux = COUCHES_RAPIDE if mode == 3 else COUCHES_ULTRA
        groupes = [(None, preparer_masques(ton, niveaux))]
        hach, esp = hachures_budget(groupes, minutes * 60, dt, fixe)
        traits = hach + contours
        info = f" (espacement des hachures : {esp:.1f} px)"
    else:  # mode 5 : couleur
        img = charger(chemin, taille, couleur=True)
        gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        encre = 255 - img.min(axis=2)                     # quantité d'encre voulue
        ton = preparer_ton(255 - encre)
        lab = cv2.cvtColor(img.astype(np.float32) / 255, cv2.COLOR_BGR2Lab)
        pal = np.array([[s["bgr"] for s in stylos]], dtype=np.float32) / 255
        pal_lab = cv2.cvtColor(pal, cv2.COLOR_BGR2Lab)[0]
        dist = ((lab[:, :, None, :] - pal_lab[None, None, :, :]) ** 2).sum(-1)
        attribue = dist.argmin(axis=2)
        niveaux = COUCHES_ULTRA if minutes >= 10 else COUCHES_RAPIDE
        groupes = []
        for k in np.argsort(-pal_lab[:, 0]):              # du plus clair au plus sombre
            ton_k = np.where(attribue == k, ton, 255).astype(np.uint8)
            groupes.append((stylos[k], preparer_masques(ton_k, niveaux)))
        noir = next((s for s in stylos if s["nom"] == "noir"), None)
        contours = traits_contours(gris, 2, 1, mini=30) if noir else []
        fixe = estimer(contours, dt) + PEN_COUT if contours else 0.0
        hach, esp = hachures_budget(groupes, minutes * 60, dt, fixe)
        dernier = next((t[1] for t in reversed(hach) if t[0] is None), None)
        fin = []
        if contours:
            if dernier is None or dernier["nom"] != "noir":
                fin.append((None, noir))
            fin.extend(contours)
        traits = hach + fin
        info = f" (espacement des hachures : {esp:.1f} px)"
    if not any(t[0] is not None for t in traits):
        raise RuntimeError("Aucun trait détecté. Augmente le détail ou change de mode.")

    apercu = np.full((*gris.shape[:2], 3), 255, np.uint8)
    col = (0, 0, 0)
    for pts, pas in traits:
        if pts is None:
            col = pas["bgr"]
            continue
        p = np.round(np.asarray(pts, np.float32)).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(apercu, [p], False, col, 1, cv2.LINE_AA)
    ok, buf = cv2.imencode(".png", apercu)
    if ok:
        buf.tofile(str(Path(__file__).resolve().parent / "apercu.png"))
    return traits, info


def configurer_stylos():
    print()
    print("Mode couleur : chaque couleur utilise un stylo différent du ruban Word.")
    print("Dans Word (onglet Dessin), donne d'abord une couleur à chaque stylo :")
    print("clique 2 fois sur le stylo -> choisis la couleur (et une épaisseur fine).")
    n = demander("Nombre de stylos à utiliser", 3, range(2, 7))
    stylos = []
    pris = set()
    for i in range(1, n + 1):
        print(f"\nStylo {i}/{n} - couleurs possibles :")
        for k, (nom, _) in enumerate(PALETTE, 1):
            print(f"  {k}. {nom}")
        while True:
            c = demander("Couleur de ce stylo", 1, range(1, len(PALETTE) + 1))
            if PALETTE[c - 1][0] in pris:
                print("Cette couleur est déjà prise, choisis-en une autre.")
                continue
            break
        nom, rgb = PALETTE[c - 1]
        pris.add(nom)
        print(f"Dans Word, le stylo {nom} doit avoir cette couleur, et être un stylo DIFFERENT des autres.")
        input("Appuie sur Entrée ici, puis tu as 6 s pour poser la souris sur ce stylo dans Word (sans cliquer)...")
        for sec in range(6, 0, -1):
            print(f"  {sec}...", end="\r")
            time.sleep(1)
        pos = tuple(souris.position)
        print(f"  Position enregistrée : {pos}   ")
        stylos.append({"nom": nom, "bgr": (rgb[2], rgb[1], rgb[0]), "pos": pos})
    return stylos


# ---------- Mode 6 : couleur dans Paint 3D (palette) ----------
FICHIER_PALETTE = Path(__file__).resolve().parent / "palette.json"


def lire_pixel(x, y):
    """Couleur [B, G, R] affichée à l'écran au point (x, y)."""
    user32, gdi32 = ctypes.windll.user32, ctypes.windll.gdi32
    user32.GetDC.restype = ctypes.c_void_p
    user32.ReleaseDC.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    gdi32.GetPixel.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    gdi32.GetPixel.restype = ctypes.c_uint32
    hdc = user32.GetDC(None)
    vals = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            c = gdi32.GetPixel(hdc, int(x) + dx, int(y) + dy)
            if c != 0xFFFFFFFF:
                vals.append((c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF))  # R, G, B
    user32.ReleaseDC(None, hdc)
    if not vals:
        raise RuntimeError("Impossible de lire la couleur à l'écran.")
    r, g, b = np.mean(vals, axis=0)
    return [int(b), int(g), int(r)]


def calibrer_palette():
    """Survole chaque pastille de Paint 3D + touche + du pavé numérique."""
    print()
    print("=== Apprentissage de la palette Paint 3D ===")
    print("1. Dans Paint 3D : Pinceaux > choisis un marqueur ou un crayon (palette visible).")
    print("2. Place la souris SUR une pastille de couleur (sans cliquer).")
    print("3. Appuie sur + du pavé numérique. Répète pour chaque couleur voulue")
    print("   (idéal : 8 à 16 couleurs, avec du noir et du blanc).")
    print("4. Quand tu as fini, appuie sur * du pavé numérique.")
    palette = []
    fini = threading.Event()

    def ajouter():
        try:
            x, y = souris.position
            bgr = lire_pixel(x, y)
            palette.append({"nom": f"couleur {len(palette) + 1}", "pos": [int(x), int(y)], "bgr": bgr})
            print(f"  Couleur {len(palette)} : RVB {bgr[::-1]} en ({x}, {y})")
        except Exception as e:
            print("  Erreur :", e)

    def filtre(msg, data):
        if data.vkCode in (106, 107):          # * et +
            if msg in (0x100, 0x104) and not bool(data.flags & 0x10):
                if data.vkCode == 107:
                    ajouter()
                else:
                    fini.set()
            cal.suppress_event()
        return True

    cal = keyboard.Listener(win32_event_filter=filtre)
    cal.start()
    try:
        while not (fini.is_set() and len(palette) >= 2):
            if fini.is_set():
                print("  Il faut au moins 2 couleurs.")
                fini.clear()
            time.sleep(0.1)
    finally:
        cal.stop()
    FICHIER_PALETTE.write_text(json.dumps(palette), encoding="utf-8")
    print(f"Palette enregistrée ({len(palette)} couleurs) dans palette.json")
    return palette


def charger_palette():
    if FICHIER_PALETTE.exists():
        try:
            pal = json.loads(FICHIER_PALETTE.read_text(encoding="utf-8"))
            if len(pal) >= 2:
                return pal
        except Exception:
            pass
    return None


def parametres_paint3d():
    palette = charger_palette()
    if palette:
        print(f"Palette enregistrée trouvée ({len(palette)} couleurs).")
        print("  1 = l'utiliser   2 = la refaire (si Paint 3D a bougé)")
        if demander("Choix", 1, (1, 2)) == 2:
            palette = None
    if not palette:
        palette = calibrer_palette()
    return {
        "palette": palette,
        "epaisseur": demander("Épaisseur du pinceau en pixels écran (essaie 6)", 6, range(1, 60)),
        "ignorer": demander("Ne pas dessiner le fond blanc ? 1 = oui, 2 = non", 1, (1, 2)) == 1,
        "contours": demander("Ajouter des contours dans la couleur la plus sombre ? 1 = oui, 2 = non",
                             1, (1, 2)) == 1,
    }


def ecrire_apercu(forme, traits, epaisseur=1):
    apercu = np.full((forme[0], forme[1], 3), 255, np.uint8)
    col = (0, 0, 0)
    for pts, pas in traits:
        if pts is None:
            col = tuple(int(v) for v in pas["bgr"])
            continue
        p = np.round(np.asarray(pts, np.float32)).astype(np.int32).reshape(-1, 1, 2)
        cv2.polylines(apercu, [p], False, col, epaisseur, cv2.LINE_AA)
    ok, buf = cv2.imencode(".png", apercu)
    if ok:
        buf.tofile(str(Path(__file__).resolve().parent / "apercu.png"))


def preparer_paint3d(chemin, taille, prm):
    palette, epaisseur = prm["palette"], prm["epaisseur"]
    bgr = charger(chemin, taille, couleur=True)
    lisse = cv2.bilateralFilter(bgr, 7, 60, 60)
    lab = cv2.cvtColor(lisse, cv2.COLOR_BGR2LAB).astype(np.float32)
    pal_bgr = np.array([q["bgr"] for q in palette], np.uint8).reshape(-1, 1, 3)
    pal_lab = cv2.cvtColor(pal_bgr, cv2.COLOR_BGR2LAB).reshape(-1, 3).astype(np.float32)

    h, w = lab.shape[:2]
    meilleur = np.full((h, w), np.inf, np.float32)
    etiq = np.zeros((h, w), np.int32)
    for k in range(len(palette)):
        dk = ((lab - pal_lab[k]) ** 2).sum(axis=2)
        m = dk < meilleur
        etiq[m] = k
        meilleur[m] = dk[m]

    blanc = (lisse.min(axis=2) > 235) if prm["ignorer"] else np.zeros((h, w), bool)
    identite = np.array([[1, 0, 0], [0, 1, 0]], np.float64)
    traits = []
    for k in np.argsort(-pal_lab[:, 0]):             # du plus clair au plus sombre
        masque = ((etiq == k) & ~blanc).astype(np.uint8) * 255
        masque = cv2.medianBlur(masque, 5)
        if (masque > 0).sum() < epaisseur * epaisseur:
            continue
        segs = lignes(masque > 0, identite, float(epaisseur))
        if segs:
            traits.append((None, palette[int(k)]))
            traits.extend(segs)

    if prm["contours"]:
        gris = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        cont = traits_contours(gris, 3, 1, mini=20)
        if cont:
            traits.append((None, palette[int(np.argmin(pal_lab[:, 0]))]))
            traits.extend(cont)

    if not any(t[0] is not None for t in traits):
        raise RuntimeError("Rien à dessiner. Mets 'ne pas dessiner le fond blanc' sur 2.")
    ecrire_apercu((h, w), traits, max(1, int(round(epaisseur))))
    return traits, ""


# ---------- Dessin ----------
def bouger(x, y):
    souris.position = (int(round(x)), int(round(y)))


def dessiner(traits):
    try:
        ox, oy = souris.position
        print("Dessin en cours... (0 pour annuler)")
        debut = time.time()
        for pts, pas in traits:
            if stop.is_set():
                break
            if pts is None:                      # changement de stylo
                souris.position = tuple(pas["pos"])
                time.sleep(0.2)
                souris.click(mouse.Button.left)
                time.sleep(0.4)
                continue
            pts = np.asarray(pts, np.float32)
            bouger(ox + pts[0][0], oy + pts[0][1])
            time.sleep(0.008)
            souris.press(mouse.Button.left)
            time.sleep(0.008)
            for a, b in zip(pts[:-1], pts[1:]):
                if stop.is_set():
                    break
                n = max(1, int(np.hypot(*(b - a)) / pas))
                for t in range(1, n + 1):
                    bouger(ox + a[0] + (b[0] - a[0]) * t / n,
                           oy + a[1] + (b[1] - a[1]) * t / n)
                    time.sleep(DELAI)
            souris.release(mouse.Button.left)
            time.sleep(0.004)
        if stop.is_set():
            print("Annulé.")
        else:
            print(f"Terminé en {format_duree(time.time() - debut)}.")
    except Exception:
        traceback.print_exc()
    finally:
        try:
            souris.release(mouse.Button.left)
        except Exception:
            pass
        etat["en_cours"] = False


def main():
    print("Python utilisé :", sys.executable)
    image = choisir_image()
    print()
    print("Modes :")
    print("  1 = Contours        (logos, formes simples)")
    print("  2 = Traits noirs    (dessins, texte)")
    print("  3 = Hachures        (photos, rendu crayon rapide)")
    print("  4 = Ultra réaliste  (photos, 7 couches d'ombres + contours)")
    print("  5 = Couleur Word    (photos, plusieurs stylos de couleur dans Word)")
    print("  6 = Couleur Paint 3D (change de couleur tout seul dans la palette)")
    mode = demander("Mode", 1, (1, 2, 3, 4, 5, 6))
    taille = demander("Taille du dessin en pixels", 800 if mode in (4, 5) else 600)
    detail, minutes, dt, stylos, p3d = 3, 0, 0.0, None, None
    if mode == 6:
        p3d = parametres_paint3d()
        print("Mesure de la vitesse de la souris...")
        dt = calibrer()
    elif mode in (1, 2):
        detail = demander("Détail (1 à 5)", 3, range(1, 6))
    else:
        if mode == 5:
            stylos = configurer_stylos()
        minutes = demander("Durée maximale en minutes",
                           20 if mode >= 4 else 5, range(1, 61))
        print("Mesure de la vitesse de la souris...")
        dt = calibrer()

    print("Analyse de l'image (peut prendre quelques secondes)...")
    if mode == 6:
        traits, info = preparer_paint3d(image, taille, p3d)
    else:
        traits, info = preparer(image, taille, detail, mode, minutes, dt, stylos)
    if mode in (3, 4, 5, 6):
        estim = estimer(traits, dt)
        print(f"Durée estimée : {format_duree(estim)}{info}")
    print(f"{len(traits)} traits. Aperçu enregistré : apercu.png (ouvre-le pour vérifier)")
    print()
    if mode == 6:
        print("Dans Paint 3D : Pinceaux > MÊME pinceau et MÊME épaisseur que pendant l'apprentissage,")
        print("palette visible, fenêtre à la même place. Ne la déplace pas.")
        print("Le programme clique tout seul sur chaque couleur. Ne touche plus à la souris.")
    elif mode == 5:
        print("Dans Word : onglet Dessin > sélectionne l'outil FLECHE (pas un stylo !).")
        print("Le programme clique tout seul sur chaque stylo. Ne touche plus à la souris.")
    else:
        print("Dans Word : onglet Dessin > Crayon FIN (clique 2 fois pour régler l'épaisseur).")
    print("Place le curseur au coin haut-gauche voulu, puis appuie sur 0 du pavé numérique.")
    print("Rappuie sur 0 pour annuler. Ctrl+C ici pour quitter.")

    def filtre(msg, data):
        if data.vkCode == VK_NUMPAD0:
            injecte = bool(data.flags & 0x10)
            if msg in (0x100, 0x104) and not injecte:
                if etat["en_cours"]:
                    stop.set()
                else:
                    stop.clear()
                    etat["en_cours"] = True
                    threading.Thread(target=dessiner, args=(traits,), daemon=True).start()
            listener.suppress_event()
        return True

    listener = keyboard.Listener(win32_event_filter=filtre)
    listener.start()
    try:
        listener.join()
    except KeyboardInterrupt:
        stop.set()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
    input("\nAppuie sur Entrée pour fermer...")
